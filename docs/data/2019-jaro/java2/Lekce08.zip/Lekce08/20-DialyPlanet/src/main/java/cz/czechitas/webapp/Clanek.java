package cz.czechitas.webapp;

public class Clanek {

    private Long id;
    private String nazev;
    private String autor;

    public Clanek() {
    }

    public Clanek(Long id, String nazev, String autor) {
        this.id = id;
        this.nazev = nazev;
        this.autor = autor;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long newValue) {
        id = newValue;
    }

    public String getNazev() {
        return nazev;
    }

    public void setNazev(String newValue) {
        nazev = newValue;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String newValue) {
        autor = newValue;
    }
}
