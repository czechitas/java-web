package cz.czechitas.webapp;

import java.util.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

@Controller
public class HlavniController {

    private List<Clanek> seznamClanku;

    public HlavniController() {
        seznamClanku = new ArrayList<>();
        seznamClanku.add(new Clanek(1000L, "O víkendu bude hezky", "Rákosníček"));
        seznamClanku.add(new Clanek(1001L, "Houbaři nosí plné košíky", "Křemílek"));
    }

    @RequestMapping("/")
    public ModelAndView zobrazIndex() {
        return new ModelAndView("redirect:/seznam.html");
    }

    @RequestMapping("/seznam.html")
    public ModelAndView zobrazSeznam() {
        ModelAndView data = new ModelAndView("seznam");
        data.addObject("seznamClanku", seznamClanku);
        return data;
    }

    @RequestMapping(value = "/{idClanku:[0-9]+}.html", method = RequestMethod.GET)
    public ModelAndView zobrazDetail(@PathVariable Long idClanku) {
        ModelAndView data = new ModelAndView("detail");
//        Clanek jeden = seznamClanku.get(idClanku);
        Clanek jeden = findById(idClanku);
        data.addObject("jedenClanek", jeden);
        return data;
    }

    @RequestMapping(value = "/{idClanku:[0-9]+}.html", method = RequestMethod.POST)
    public ModelAndView zpracujDetail(@PathVariable Long idClanku, ) {
        seznamClanku.add(new Clanek(idClanku, ));

        // vrat se na uvodni stranku
    }


    private Clanek findById(Long id) {
        for (Clanek clanek : seznamClanku) {
            if (clanek.getId().equals(id)) {
                return clanek;
            }
        }
        return null;
    }

}
