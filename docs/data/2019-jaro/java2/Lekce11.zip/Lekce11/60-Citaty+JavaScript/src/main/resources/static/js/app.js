"use strict";

var elemQuoteText = document.querySelector("#quoteText");
elemQuoteText.innerText = "Testing if it works";

/*
 nactiVyrok();

function nactiVyrok() {
    console.log("Starting HTTP request");
    var httpKlient = new XMLHttpRequest();
    httpKlient.onload = hotovo;
    httpKlient.onerror = chyba;
    httpKlient.open("GET", "_____HTTP_ADRESA_____", true);
    httpKlient.send();
}

function hotovo() {
    console.log(this.response);
}

function chyba(err) {
    console.log(err);
}
*/


