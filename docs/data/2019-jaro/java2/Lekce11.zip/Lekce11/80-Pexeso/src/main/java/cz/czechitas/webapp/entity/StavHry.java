package cz.czechitas.webapp.entity;

public enum  StavHry {

    HRAC1_VYBER_PRVNI_KARTY,
    HRAC1_VYBER_DRUHE_KARTY,
    HRAC1_ZOBRAZENI_VYHODNOCENI,
    KONEC

}
