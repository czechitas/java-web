package cz.czechitas.webapp.controller;

public class Tah {

    private int poziceKarty;

    public int getPoziceKarty() {
        return poziceKarty;
    }

    public void setPoziceKarty(int newValue) {
        poziceKarty = newValue;
    }
}
