package cz.czechitas.recept.suroviny;

import cz.czechitas.recept.suroviny.intf.*;

public class PrasekDoPeciva extends AbstractNadobaSeSypkouSurovinou {

    public PrasekDoPeciva(String jmeno) {
        super(jmeno, 25);
    }
}
