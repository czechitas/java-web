package cz.czechitas.banka;

public class SpousteciTrida {

    public static void main(String[] args) {
        NormalAccountTest tester1 = new NormalAccountTest();
        OverdraftAccountTest tester2 = new OverdraftAccountTest();
        SavingsAccountTest tester3 = new SavingsAccountTest();

        tester1.testNormalAccount();
        tester2.testOverdraftAccount();
        tester3.testSavingsAccount();
    }

}
