package cz.czechitas.webapp;

import java.util.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

@Controller
public class HlavniController {

    @RequestMapping("/")
    public ModelAndView zobrazIndex() {
        ModelAndView drzakNaDataAJmenoStranky = new ModelAndView("index");

        List<Zbozi> seznamZbozi = new ArrayList<>();
        seznamZbozi.add(new Zbozi("Milka", 2));
        seznamZbozi.add(new Zbozi("Ritter Sport", 5));
        seznamZbozi.add(new Zbozi("Studentská pečeť", 3));
        seznamZbozi.add(new Zbozi("Raciolky", 0));
        drzakNaDataAJmenoStranky.addObject(
                "seznamVyrobku", seznamZbozi);

        return drzakNaDataAJmenoStranky;
    }

}
