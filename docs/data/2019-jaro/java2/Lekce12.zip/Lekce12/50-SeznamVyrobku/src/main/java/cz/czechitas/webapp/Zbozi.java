package cz.czechitas.webapp;

public class Zbozi {

    private String nazev2;
    private int mnozstvi3;

    public Zbozi(String nazev, int mnozstvi) {
        this.nazev2 = nazev;
        this.mnozstvi3 = mnozstvi;
    }

    public String getNazev() {
        return nazev2;
    }

    public void setNazev(String newValue) {
        nazev2 = newValue;
    }

    public int getMnozstvi() {
        return mnozstvi3;
    }

    public void setMnozstvi(int newValue) {
        mnozstvi3 = newValue;
    }
}
