package cz.czechitas.webapp;

import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

@Controller
public class HlavniController {

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView zobrazIndex() {
        ModelAndView data = new ModelAndView("index");
        return data;
    }

    @RequestMapping(value = "/", method = RequestMethod.POST)
    public ModelAndView zpracujIndex(IndexForm vstup) {
        int soucet = vstup.getCislo1() + vstup.getCislo2();

        ModelAndView data = new ModelAndView("vysledek");
        data.addObject("cisloA", vstup.getCislo1());
        data.addObject("cisloB", vstup.getCislo2());
        data.addObject("celkovySoucet", soucet);
        return data;
    }

}
