package cz.czechitas.webapp;

public class IndexForm {

    private int cislo1;
    private int cislo2;

    public int getCislo1() {     // -> cislo1
        return cislo1;
    }

    public void setCislo1(int newValue) {
        cislo1 = newValue;
    }

    public int getCislo2() {      // -> cislo2
        return cislo2;
    }

    public void setCislo2(int newValue) {
        cislo2 = newValue;
    }
}
