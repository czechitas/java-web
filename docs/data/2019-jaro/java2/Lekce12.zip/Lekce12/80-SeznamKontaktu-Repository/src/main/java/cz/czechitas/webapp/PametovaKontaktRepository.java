package cz.czechitas.webapp;

import java.util.*;

public class PametovaKontaktRepository {

    public static List<Kontakt> seznamKontaktu = new ArrayList<>(Arrays.asList(
            new Kontakt(100L, "Thomas Alva Edison", "+1-123-555-666", "thomas@edison.com"),
            new Kontakt(101L, "Albert Einstein", "+41 953 203 569", "albert.einstein@cern.ch"),
            new Kontakt(102L, "Kamil Ševeček", "+420 604 111 222", "kamil.sevecek@czechitas.cz")
    ));
    private Long nejvyssiId = 900L;

    public synchronized List<Kontakt> findAll() {
        List<Kontakt> clanky = new ArrayList<>(seznamKontaktu.size());
        for (Kontakt jedenKontakt : seznamKontaktu) {
            clanky.add(clone(jedenKontakt));
        }
        return clanky;
    }

    public synchronized Kontakt findById(Long id) {
        int index = najdiIndexZaznamu(id);
        if (index == -1) {
            return null;
        }
        return clone(seznamKontaktu.get(index));
    }

    public synchronized Kontakt save(Kontakt zaznamKUlozeni) {
        int index = najdiIndexZaznamu(zaznamKUlozeni.getId());
        if (index == -1) {
            return pridej(zaznamKUlozeni);
        }
        return updatuj(zaznamKUlozeni, index);
    }

    public synchronized void delete(Long id) {
        int index = najdiIndexZaznamu(id);
        if (index == -1) return;
        seznamKontaktu.remove(index);
    }

    //-------------------------------------------------------------------------

    private Kontakt updatuj(Kontakt zaznamKUlozeni, int index) {
        Kontakt jedenKontakt = clone(zaznamKUlozeni);
        seznamKontaktu.set(index, jedenKontakt);
        return clone(jedenKontakt);
    }

    private Kontakt pridej(Kontakt zaznamKPridani) {
        Kontakt jedenKontakt = clone(zaznamKPridani);
        nejvyssiId = nejvyssiId + 1L;
        jedenKontakt.setId(nejvyssiId);
        seznamKontaktu.add(jedenKontakt);
        return clone(jedenKontakt);
    }

    private int najdiIndexZaznamu(Long id) {
        if (id == null) {
            return -1;
        }
        for (int i = 0; i < seznamKontaktu.size(); i++) {
            Kontakt jedenKontakt = seznamKontaktu.get(i);
            if (jedenKontakt.getId().equals(id)) {
                return i;
            }
        }
        return -1;
    }

    private Kontakt clone(Kontakt puvodni) {
        return new Kontakt(puvodni.getId(), puvodni.getJmeno(), puvodni.getTelefonniCislo(), puvodni.getEmail());
    }

}
