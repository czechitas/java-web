package cz.czechitas.webapp;

import java.util.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;

@Controller
public class HlavniController {

    private KontaktRepository kontaktRepository = new JdbcKontaktRepository();

    @RequestMapping("/")
    public ModelAndView zobrazIndex() {
        return new ModelAndView("redirect:/seznam.html");
    }

    @RequestMapping("/seznam.html")
    public ModelAndView zobrazSeznam() {
        ModelAndView drzakNaDataAJmenoStranky = new ModelAndView("seznam");
        List<Kontakt> kontakty = kontaktRepository.findAll();
        drzakNaDataAJmenoStranky.addObject("seznamKontaktu", kontakty);
        return drzakNaDataAJmenoStranky;
    }

    @RequestMapping(value = "/{idKontaktu:[0-9]+}.html", method = RequestMethod.GET)
    public ModelAndView zobrazDetail(@PathVariable Long idKontaktu) {
        ModelAndView drzakNaDataAJmenoStranky = new ModelAndView("detail");
        Kontakt nalezeny = kontaktRepository.findById(idKontaktu);
        DetailForm formularovaData = new DetailForm();
        formularovaData.setJmeno(nalezeny.getJmeno());
        formularovaData.setTelefonniCislo(nalezeny.getTelefonniCislo());
        formularovaData.setEmail(nalezeny.getEmail());
        drzakNaDataAJmenoStranky.addObject("kontakt", formularovaData);
        return drzakNaDataAJmenoStranky;
    }

    @RequestMapping(value = "/{idKontaktu:[0-9]+}.html", method = RequestMethod.POST)
    public ModelAndView zpracujDetail(@PathVariable Long idKontaktu, DetailForm formular) {
        Kontakt kontakt = kontaktRepository.findById(idKontaktu);
        if (kontakt != null) {
            kontakt.setJmeno(formular.getJmeno());
            kontakt.setTelefonniCislo(formular.getTelefonniCislo());
            kontakt.setEmail(formular.getEmail());
            kontaktRepository.save(kontakt);
        }
        return new ModelAndView("redirect:/seznam.html");
    }

    @RequestMapping(value = "/{idKontaktu:[0-9]+}/delete")
    public ModelAndView zpracujSmazani(@PathVariable Long idKontaktu) {
        kontaktRepository.delete(idKontaktu);
        return new ModelAndView("redirect:/seznam.html");
    }

    @RequestMapping(value = "/new.html", method = RequestMethod.GET)
    public ModelAndView zobrazNovyDetail() {
        ModelAndView drzakNaDataAJmenoStranky = new ModelAndView("detail");
        DetailForm formularovaData = new DetailForm();
        drzakNaDataAJmenoStranky.addObject("kontakt", formularovaData);
        return drzakNaDataAJmenoStranky;
    }

    @RequestMapping(value = "/new.html", method = RequestMethod.POST)
    public ModelAndView zpracujNovyDetail(DetailForm formular) {
        Kontakt kontakt = new Kontakt();
        kontakt.setJmeno(formular.getJmeno());
        kontakt.setTelefonniCislo(formular.getTelefonniCislo());
        kontakt.setEmail(formular.getEmail());
        kontaktRepository.save(kontakt);
        return new ModelAndView("redirect:/seznam.html");
    }

}
