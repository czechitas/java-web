package cz.czechitas.webapp;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class SouborovaKontaktRepository implements KontaktRepository {

    public static final Pattern REGEX_RADKU = Pattern.compile("([0-9]+)[,;]\"(.*?)\"[,;]\"(.*?)\"[,;]\"(.*?)\"");
    private Long nejvyssiId = 900L;

    public synchronized List<Kontakt> findAll() {
        try {
            List<String> radky = Files.readAllLines(Paths.get("kontakty.csv"));

            List<Kontakt> seznamKontaktu = new ArrayList<>(radky.size());
            for (String radek : radky) {
                Kontakt jedenKontakt = prevedRadekNaKontakt(radek);
                if (jedenKontakt == null) continue;
                seznamKontaktu.add(jedenKontakt);
            }
            return seznamKontaktu;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public synchronized Kontakt findById(Long id) {
        List<Kontakt> seznamKontaktu = findAll();
        int index = najdiIndexZaznamu(seznamKontaktu, id);
        if (index == -1) {
            return null;
        }
        return clone(seznamKontaktu.get(index));
    }

    public synchronized Kontakt save(Kontakt zaznamKUlozeni) {
        List<Kontakt> seznamKontaktu = findAll();
        int index = najdiIndexZaznamu(seznamKontaktu, zaznamKUlozeni.getId());
        if (index == -1) {
            return pridej(seznamKontaktu, zaznamKUlozeni);
        }
        return updatuj(seznamKontaktu, zaznamKUlozeni, index);
    }

    public synchronized void delete(Long id) {
        List<Kontakt> seznamKontaktu = findAll();
        int index = najdiIndexZaznamu(seznamKontaktu, id);
        if (index == -1) return;
        seznamKontaktu.remove(index);
        ulozClanky(seznamKontaktu);
    }

    //-------------------------------------------------------------------------

    private Kontakt updatuj(List<Kontakt> seznamKontaktu, Kontakt zaznamKUlozeni, int index) {
        Kontakt kontakt = clone(zaznamKUlozeni);
        seznamKontaktu.set(index, kontakt);
        ulozClanky(seznamKontaktu);
        return clone(kontakt);
    }

    private Kontakt pridej(List<Kontakt> seznamKontaktu, Kontakt zaznamKPridani) {
        Kontakt kontakt = clone(zaznamKPridani);
        nejvyssiId = nejvyssiId + 1L;
        kontakt.setId(nejvyssiId);
        seznamKontaktu.add(kontakt);
        ulozClanky(seznamKontaktu);
        return clone(kontakt);
    }

    private int najdiIndexZaznamu(List<Kontakt> seznamKontaktu, Long id) {
        if (id == null) {
            return -1;
        }
        for (int i = 0; i < seznamKontaktu.size(); i++) {
            Kontakt jedenKontakt = seznamKontaktu.get(i);
            if (jedenKontakt.getId().equals(id)) {
                return i;
            }
        }
        return -1;
    }

    private Kontakt prevedRadekNaKontakt(String radek) {
        Matcher regularniAutomat = REGEX_RADKU.matcher(radek);
        if (!regularniAutomat.find()) return null;

        Kontakt jedenKontakt = new Kontakt();
        jedenKontakt.setId(Long.parseLong(regularniAutomat.group(1)));
        jedenKontakt.setJmeno(regularniAutomat.group(2));
        jedenKontakt.setTelefonniCislo(regularniAutomat.group(3));
        jedenKontakt.setEmail(regularniAutomat.group(4));
        return jedenKontakt;
    }

    private Kontakt clone(Kontakt puvodni) {
        return new Kontakt(puvodni.getId(), puvodni.getJmeno(), puvodni.getTelefonniCislo(), puvodni.getEmail());
    }

    private void ulozClanky(List<Kontakt> seznamKontaktu) {
        try {
            List<String> radky = new ArrayList<>(seznamKontaktu.size());
            for (Kontakt jedenKontakt : seznamKontaktu) {
                String radek = prevedKontaktNaRadekCsv(jedenKontakt);
                radky.add(radek);
            }
            Files.write(Paths.get("kontakty.csv"), radky, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String prevedKontaktNaRadekCsv(Kontakt jedenKontakt) {
        return jedenKontakt.getId() + ",\"" + jedenKontakt.getJmeno() + "\",\"" + jedenKontakt.getTelefonniCislo() + "\",\"" + jedenKontakt.getEmail() + "\"";
    }

}
