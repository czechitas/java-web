package cz.czechitas.webapp;

public class NovaForm {

    private String jmeno;
    private String vrsek;
    private String spodek;

    public String getJmeno() {
        return jmeno;
    }

    public void setJmeno(String newValue) {
        jmeno = newValue;
    }

    public String getVrsek() {
        return vrsek;
    }

    public void setVrsek(String newValue) {
        vrsek = newValue;
    }

    public String getSpodek() {
        return spodek;
    }

    public void setSpodek(String newValue) {
        spodek = newValue;
    }
}
