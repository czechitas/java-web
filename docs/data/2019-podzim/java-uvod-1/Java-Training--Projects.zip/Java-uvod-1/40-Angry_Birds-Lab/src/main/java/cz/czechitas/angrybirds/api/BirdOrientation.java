package cz.czechitas.angrybirds.api;

public enum BirdOrientation {

    WEST,
    EAST,
    NORTH,
    SOUTH

}
