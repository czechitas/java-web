package cz.czechitas.kockamyssyr;

import java.util.*;
import cz.czechitas.kockamyssyr.api.*;
import net.sevecek.util.*;

public class HlavniProgram {

    public void main(String[] args) {
        new Tree(500, 0);
        new Tree(600, 150);

        // TODO: Sem vepiste svuj program
    }

}
