package cz.czechitas.kockamyssyr;

import java.util.*;
import cz.czechitas.kockamyssyr.api.*;

public class HlavniProgram {

    public void main(String[] args) {
        new Tree(500, 0);
        new Tree(600, 150);

        // Vytvořte objekt kočky a projděte se s ní.
        Cat tom = new Cat(300, 300);
//        tom.moveForward(550);
//        tom.turnRight();
//        tom.turnRight();
//        tom.moveForward(550);
//        tom.turnLeft();
//        tom.turnLeft();
        tom.setBrain(it -> {
            while (true) {
                tom.moveForward(550);
                tom.turnRight();
                tom.turnRight();
                tom.moveForward(550);
                tom.turnLeft();
                tom.turnLeft();
            }
        });

        // Položte pár stromů na herní plochu. Třeba takhle:
        new Tree(850, 450);
        new Tree(750, 550);

        // Položte na zkoušku i 1 jitrnici. Třeba sem:
        new Meat(50, 50);

        // Udělejte řadu stromů
        for (int i=0; i<9; i++) {
            new Tree(100, 50 + i*50);
        }

        // Naprogramujte myš tak, aby se ovládala pomocí šipek na klávesnici.
        Mouse jerry;
        KeyboardBrain ovladacMysi;
        jerry = new Mouse(400, 250);
        // ovladacMysi = new KeyboardBrain();
        ovladacMysi = new KeyboardBrain(KeyCode.UP, KeyCode.LEFT, KeyCode.DOWN, KeyCode.RIGHT);
        jerry.setBrain(ovladacMysi);

        // Naprogramujte kočku tak, aby obcházela digitální ležatou osmičku od kraje okna ke kraji.
        Cat sylvester = new Cat(0, 0);
        sylvester.setBrain(it -> {
            while (true) {
                sylvester.moveForward(500);
                sylvester.turnRight();
                sylvester.moveForward(600);
                sylvester.turnLeft();
                sylvester.moveForward(500);
                sylvester.turnLeft();
                sylvester.moveForward(600);
                sylvester.turnLeft();
                sylvester.moveForward(500);
                sylvester.turnLeft();
                sylvester.moveForward(600);
                sylvester.turnRight();
                sylvester.moveForward(500);
                sylvester.turnRight();
                sylvester.moveForward(550);
                sylvester.turnRight();
            }
        });

        // Vytvořte bludiště ze stromů.
        for (int i=0; i<6; i++) {
            new Tree(150 + i * 50, 50);
        }
        for (int i=0; i<5; i++) {
            new Tree(600 + i*50, 50);
        }
        for (int i=0; i<4; i++) {
            new Tree(150 + i*50, 450);
        }
        for (int i=0; i<5; i++) {
            new Tree(650 + i*50, 400);
        }
        for (int i=0; i<4; i++) {
            new Tree(850, 200 + i*50);
        }
        for (int i=0; i<4; i++) {
            new Tree(450 + i * 50, 550);
        }
        new Tree(150, 250);
        new Tree(250, 200);
        for (int i=0; i<2; i++) {
            new Tree(250 + i*50, 250);
        }
        new Tree(800, 150);
        new Tree(800, 100);

        // Vytvořte 3 sýry na náhodných pozicích. Pokud budete mít na herní ploše myš
        // (například ovládanou z klávesnice).
        // Uvidíte, že až myš sesbírá všechny sýry, hra ohlásí vítězství.
        Random generatorNahodnychCisel = new Random();
        for (int i = 0; i < 3; i++) {
            int x;
            int y;
            x = generatorNahodnychCisel.nextInt(900);
            y = generatorNahodnychCisel.nextInt(550);
            new Cheese(x, y);
        }

        // Přidejte na herní plochu 4 náhodně umístěné jitrnice.
        // Myš nyní musí sesbírat jak sýry, tak jitrnice.
        for (int i = 0; i < 3; i++) {
            int x;
            int y;
            x = generatorNahodnychCisel.nextInt(900);
            y = generatorNahodnychCisel.nextInt(550);
            new Meat(x, y);
        }


        // Hra kočka proti myši pro dva hráče.
        // Kočka honí pomocí kláves W, A, S, D, myš utíká pomocí šipek.
        // Když dříve sežere kočka myš, myš prohrála. Když myš dříve
        // sežere všechny sýry, vyhrála myš.

        // Do programu přidejte ještě další kočku. Říkejme jí třeba Scratchy.
        // Nechejte tuto kočku ovládat pomocí kláves W, A, S, D.
        Cat scratchy;
        KeyboardBrain ovladacScratchyho;
        scratchy = new Cat(600, 500);
        ovladacScratchyho = new KeyboardBrain(KeyCode.W, KeyCode.A, KeyCode.S, KeyCode.D);
        scratchy.setBrain(ovladacScratchyho);


        // Hra kočka proti myši pro jednoho hráče.
        // Kočka honí myš - pohybuje se náhodně.
        // Když dříve sežere kočka myš, myš prohrála. Když myš dříve
        // sežere všechny sýry, vyhrála myš.

        // Rozšiřte hru ještě o jednu kočku. Říkejme jí třeba Garfield.
        // Vytvořte kočce Brain tak, aby se pohybovala pořád rovně, dokud nenarazí.
        // Po nárazu se otočí na náhodnou stranu (doleva nebo doprava) a opět bude pokračovat rovně, dokud nenarazí.
        Cat garfield;
        garfield = new Cat(250, 350);
        garfield.setBrain(it -> {
            while (true) {
                while (garfield.isPossibleToMoveForward()) {
                    garfield.moveForward();
                }
                int nahodnySmer = generatorNahodnychCisel.nextInt(2);
                if (nahodnySmer == 0) {
                    garfield.turnLeft();
                } else {
                    garfield.turnRight();
                }
            }
        });
    }

}
