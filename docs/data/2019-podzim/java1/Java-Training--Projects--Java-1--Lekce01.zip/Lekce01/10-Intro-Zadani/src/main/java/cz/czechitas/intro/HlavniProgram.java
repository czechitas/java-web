package cz.czechitas.intro;

import cz.czechitas.intro.api.*;
import net.sevecek.util.*;

public class HlavniProgram {

    public void main(String[] args) {

        new AngryRed(400, 200);
        // TODO: Sem vepiste svuj program

    }

}
