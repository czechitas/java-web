package cz.czechitas.angrybirds.engine.tiles;

public class ExplosionTile extends GenericTile {

    public ExplosionTile() {
        super("explosion.png");
    }
}
