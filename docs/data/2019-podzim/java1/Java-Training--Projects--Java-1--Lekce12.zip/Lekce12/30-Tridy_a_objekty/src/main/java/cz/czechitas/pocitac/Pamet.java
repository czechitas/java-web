package cz.czechitas.pocitac;

public class Pamet {

    long kapacita;

    public void vypisInfo() {
        System.out.print("RAM: " + kapacita + " bajtu");
    }

}
