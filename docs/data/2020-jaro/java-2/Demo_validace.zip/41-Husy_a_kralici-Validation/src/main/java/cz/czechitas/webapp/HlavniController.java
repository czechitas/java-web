package cz.czechitas.webapp;

import javax.validation.*;
import org.springframework.stereotype.*;
import org.springframework.ui.*;
import org.springframework.validation.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.support.*;

@Controller
public class HlavniController {

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView zobrazIndex(Model predvyplnenyModel) {
        ModelAndView drzakNaDataAJmenoSablony = new ModelAndView("index");
        if (!predvyplnenyModel.containsAttribute("formular")) {
            drzakNaDataAJmenoSablony.addObject("formular", new HusyAKraliciForm());
        }
        return drzakNaDataAJmenoSablony;
    }

    @RequestMapping(value = "/", method = RequestMethod.POST)
    public ModelAndView zpracujIndex(@Valid HusyAKraliciForm vyplnenyFormular, BindingResult validacniChyby, RedirectAttributes flashScope) {
        if (validacniChyby.hasErrors()) {
            ModelAndView drzakNaDataAJmenoSablony = new ModelAndView("redirect:/");
            flashScope.addFlashAttribute("formular", vyplnenyFormular);
            flashScope.addFlashAttribute(BindingResult.MODEL_KEY_PREFIX + "formular", validacniChyby);
            return drzakNaDataAJmenoSablony;
        }

        ModelAndView drzakNaDataAJmenoSablony = new ModelAndView("vysledek");
        int pocetHus = Integer.parseInt(vyplnenyFormular.getPocetHus());
        int pocetKraliku = Integer.parseInt(vyplnenyFormular.getPocetKraliku());
        int pocetNohou = pocetHus * 2 + pocetKraliku * 4;
        int pocetHlav = pocetHus + pocetKraliku;
        drzakNaDataAJmenoSablony.addObject("pocetNohou", pocetNohou);
        drzakNaDataAJmenoSablony.addObject("pocetHlav", pocetHlav);
        return drzakNaDataAJmenoSablony;
    }
}
