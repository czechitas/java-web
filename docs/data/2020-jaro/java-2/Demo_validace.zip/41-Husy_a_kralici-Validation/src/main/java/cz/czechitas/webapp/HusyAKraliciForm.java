package cz.czechitas.webapp;

import javax.validation.constraints.*;

public class HusyAKraliciForm {

    @Pattern(regexp = "[0-9]+", message = "Hodnota musí být číslo")
    @Min(value = 0, message = "Číslo musí být min {value}")
    @Max(value = 100, message = "Číslo musí být max {value}")
    private String pocetHus;

    @Pattern(regexp = "[0-9]+", message = "Hodnota musí být číslo")
    @Min(value = 0, message = "Číslo musí být min {value}")
    @Max(value = 100, message = "Číslo musí být max {value}")
    private String pocetKraliku;

    public String getPocetHus() {
        return pocetHus;
    }

    public void setPocetHus(String newValue) {
        pocetHus = newValue;
    }

    public String getPocetKraliku() {
        return pocetKraliku;
    }

    public void setPocetKraliku(String newValue) {
        pocetKraliku = newValue;
    }
}
