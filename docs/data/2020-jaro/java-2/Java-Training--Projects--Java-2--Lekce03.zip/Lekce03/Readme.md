Lekce 03
========

Více o šablonách stránek - Thymeleaf
------------------------------------

### Osnova

- for-each v šabloně
    - Dynamicky generovaný seznam (Stringů)
    - Dynamicky generovaná tabulka (Zboží)
- Koncept Thymeleaf a staticky zobrazitelná šablona v prohlížeči (bez Javy)


### Videozáznam

Na YouTube je k dispozici:
* [záznam z lekce (2019)](https://www.youtube.com/watch?v=W2ejBH-F6JE)
* [záznam z lekce (2018)](https://www.youtube.com/watch?v=2exrkEkaxIU)
* [záznam z lekce (2017)](https://www.youtube.com/watch?v=TNN8twisoow)
* [záznam z lekce - bonus (2017)](https://www.youtube.com/watch?v=-Njd3uhThOo)

Případně je k dispozici playlist všech lekcí:
* [Jaro 2019](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ7I5m_zJtjZoLS-pxSi859Z)
* [Jaro 2018](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ6mcuJ1VaY8s0mzFsaMUzp-)
* [Jaro 2017](https://www.youtube.com/playlist?list=PLUVJxzuCt9ATwP3dFn5xCHvObtu2EveNZ)
