package cz.czechitas.webapp.entity;

public enum StavKarty {

    LICEM_NAHORU,
    RUBEM_NAHORU,
    ODEBRANA

}
