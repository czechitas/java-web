package cz.czechitas.recept.suroviny.intf;

public interface NadobaSKusovouSurovinou {

    boolean snizPocet();

    String getJmeno();
}
