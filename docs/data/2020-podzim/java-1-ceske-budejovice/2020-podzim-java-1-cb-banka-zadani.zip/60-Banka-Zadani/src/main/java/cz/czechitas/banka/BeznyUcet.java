package cz.czechitas.banka;

public class BeznyUcet {

}
