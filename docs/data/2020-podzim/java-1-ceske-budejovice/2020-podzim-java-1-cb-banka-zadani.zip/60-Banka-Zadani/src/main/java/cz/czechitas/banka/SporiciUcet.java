package cz.czechitas.banka;

public class SporiciUcet {

}
