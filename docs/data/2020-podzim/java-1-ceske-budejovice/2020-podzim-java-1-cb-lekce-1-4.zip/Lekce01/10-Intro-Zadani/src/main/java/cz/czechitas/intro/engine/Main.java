package cz.czechitas.intro.engine;

import cz.czechitas.intro.*;

public class Main {

    public static void main(String[] args) {
        new HlavniProgram().main(args);
    }

}
