Lekce 02 - Želva Žofka
----------------------

### Osnova

* Opakování Bublaniny
* Želva Žofka
    * Čtverec
    * Trojúhelník
    * Cyklus
    * Vlastní metody
    * Domeček
    * Město
    * Prasátko



### Videozáznam

Na YouTube je k dispozici playlist všech lekcí:
* [Jaro 2020](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ6qqLUbTUvUyt2GcwnyjtRp)
* [Podzim 2019](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ7tIik1OiuPmGwt4OOqomrR)
* [Podzim 2018](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ70H8jF9FxPs15e3_m6su80)
* [Podzim 2017](https://www.youtube.com/playlist?list=PLUVJxzuCt9AROpKl3Hu-DvdgQV-xHaoQY)
