package cz.czechitas.kockamyssyr.api;

import javax.swing.*;

public interface Stackable {

    Icon getStackableIcon();

}
