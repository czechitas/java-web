Lekce 04 - Metody s návratovými hodnotami
-----------------------------------------

Kočka-myš-sýr
-------------

Pro inspiraci seznam animovaných koček a myší:

### Myši

Speedy Gonzales
Jerry
Monty jack
Mickey
Minnie
Ruda
Koumák
Stuart
Itchy

### Kočky

Tom
Sylvester
Azrael
Stimpy
Scratchy
Garfield



### Videozáznam

Na YouTube je k dispozici playlist všech lekcí:
* [Jaro 2020](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ6qqLUbTUvUyt2GcwnyjtRp)
* [Podzim 2019](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ7tIik1OiuPmGwt4OOqomrR)
* [Podzim 2018](https://www.youtube.com/playlist?list=PLTCx5oiCrIJ70H8jF9FxPs15e3_m6su80)
* [Podzim 2017](https://www.youtube.com/playlist?list=PLUVJxzuCt9AROpKl3Hu-DvdgQV-xHaoQY)
