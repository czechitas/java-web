package com.ryzizub;

public class Clovek {
    private String jmeno;
    int vyska;

    Clovek(String vstupJmeno, int vstupVyska) {
        jmeno = vstupJmeno;
        vyska = vstupVyska;
    }

    public String getJmeno(){
        return jmeno;
    }

    public void pozdravX(int kolikrat) {
        for (int i = 0; i < kolikrat; i++){
            System.out.println("Dominik zdravi");
        }
    }

}

