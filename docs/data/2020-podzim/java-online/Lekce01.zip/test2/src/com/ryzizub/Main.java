package com.ryzizub;

public class Main {
//    protected static int mojeCislo= 1;

    public static void main(String[] args) {
//        Clovek dominik = new Clovek("Dominik", 191);
//        System.out.println(dominik.getJmeno());
//        dominik.pozdravX(10);
//        pozdrav(1, "Czechitas");
//        System.out.println("ahoj");
//        int myNumber = 1;
//        boolean neco = false;
//        double myDouble = 1.6;
//        String slovo = "mojeSlovo";
//        String[] muj = {"moje", "adad"};
//        mojeCislo = 2;


//        for (int i = 0; i < 10; i++){
//            System.out.println("ahoj " + i);
//        }

//        int pocitatko = 0;
//
//        do {
//            System.out.println("ahoj " + pocitatko);
//        } while (pocitatko > 0);
//
//        while (pocitatko > 0) {
//            System.out.println("ahoj " + pocitatko);
//        }
	// write your code here
//        odeslatEmail("blab@vsm.cz")
    }

//    private static void pozdrav(int pocetPozdravu, String koho){
//        if (pocetPozdravu == 0){
//            System.out.println("dej minimum pozdravu aspon 1");
//        } else {
//            for (int i = 0; i < pocetPozdravu; i++){
//                System.out.println("ahoj " + koho + " " + i);
//            }
//        }
//    }
}

