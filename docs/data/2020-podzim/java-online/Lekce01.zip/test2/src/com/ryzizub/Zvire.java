package com.ryzizub;

public class Zvire {
    String jmeno;
    int vaha;
    int velikost;

    Zvire(String vstupJmeno, int vstupVaha, int vstupVelikost) {
        jmeno = vstupJmeno;
        vaha = vstupVaha;
        vstupVelikost = vstupVelikost;
    }
}
