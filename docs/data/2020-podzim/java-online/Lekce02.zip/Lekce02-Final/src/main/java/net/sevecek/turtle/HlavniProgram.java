package net.sevecek.turtle;

import net.sevecek.turtle.engine.Turtle;

import java.awt.*;

public class HlavniProgram {

    Turtle zofka;
    Color hlavniBarva = Color.BLACK;

    public void main(String[] args) {
        zofka = new Turtle();
        zofka.setX(0);
        zofka.setY(0);

        int velikostTrojuhelnik = 200;
        zofka.penUp();
        nakreslitPrase(velikostTrojuhelnik);
    }

    public void nakreslitPrase(int velikost){
        zofka.setPenColor(Color.PINK);
        zofka.turnLeft(90);
        nakreslitDomecek(velikost);
        zofka.turnLeft(90);
        nakreslitNohu(velikost / 2);
        zofka.turnLeft(90);
        zofka.move(velikost);
        zofka.turnRight(90);
        nakreslitNohu(velikost / 2);
        zofka.penDown();
        zofka.turnLeft(180);
        zofka.move(velikost);
        zofka.turnRight(60);
        zofka.move(velikost/2);
        zofka.turnRight(180);
        zofka.move(velikost/2);
        zofka.turnLeft(60);
        zofka.move(velikost);
        zofka.turnRight(90);
        zofka.move(velikost);
        zofka.turnRight(90);
        zofka.penUp();
        zofka.setPenColor(hlavniBarva);
    }

    public void nakreslitNohu(int velikost){
        zofka.penDown();
        zofka.turnLeft(30);
        zofka.move(velikost);
        zofka.turnLeft(180);
        zofka.move(velikost);
        zofka.turnLeft(120);
        zofka.move(velikost);
        zofka.turnLeft(180);
        zofka.move(velikost);
        zofka.turnRight(150);
        zofka.penUp();
    }

    public void nakreslitDomecek(int velikost) {
        nakreslitTrojuhlenik(velikost);
        nakreslitCtverec(velikost);
    }

    public void nakreslitTrojuhlenik(int velikost) {
        zofka.penDown();
        zofka.turnRight(30);
        zofka.move(velikost);
        for (int i = 0; i < 2; i++) {
            zofka.turnRight(120);
            zofka.move(velikost);
        }
        zofka.turnRight(90);
        zofka.penUp();
    }

    public void nakreslitCtverec(int velikost){
        zofka.penDown();
        for (int i = 0; i < 4; i++) {
            zofka.turnRight(90);
            zofka.move(velikost);
        }
        zofka.penUp();
    }

}
