package net.sevecek.turtle;

import net.sevecek.turtle.engine.*;

import java.awt.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HlavniProgram {

    private static final Color HLAVNI_BARVA = Color.BLACK;
    private static final int HLAVNI_VELIKOST = 30;

    public void main(String[] args) {
        ExecutorService paralel = Executors.newCachedThreadPool();
        paralel.execute(this::kreslitZofka1);
        paralel.execute(this::kreslitZofka2);
        paralel.shutdown();
        Turtle zofk3 = new Turtle();
        nakreslitCtverec(100, zofk3, Color.CYAN, HLAVNI_VELIKOST);
        Turtle zofk4 = new Turtle();
        nakreslitCtverec(100, zofk4, Color.PINK, HLAVNI_VELIKOST);
    }

    public void kreslitZofka1() {
        Turtle zofka = new Turtle();
        zofka.penUp();// Cerveny ctverec vlevo o velikost 100
        zofka.turnLeft(90);
        zofka.move(100);
        zofka.turnRight(90);
        nakreslitCtverec(100, zofka, Color.RED, HLAVNI_VELIKOST);

    }

    public void kreslitZofka2() {
        Turtle zofka2 = new Turtle();
        zofka2.penUp();// Zeleny ctverec vpravo o velikost 150
        zofka2.turnRight(90);
        zofka2.move(100);
        zofka2.turnLeft(90);
        nakreslitCtverec(150, zofka2, Color.GREEN, HLAVNI_VELIKOST);
    }

    public void nakreslitCtverec(int a, Turtle kreslic, Color barva, int velikostPera){
        kreslic.penDown();
        kreslic.setPenColor(barva);
        kreslic.setPenWidth(velikostPera);
        for (int i = 0; i < 4; i++){
            kreslic.move(a);
//            if (kreslitVpravo){
                kreslic.turnRight(90);
//            } else {
//                kreslic.turnLeft(90);
//            }
        }
        kreslic.penUp();
        kreslic.setPenWidth(HLAVNI_VELIKOST);
        kreslic.setPenColor(HLAVNI_BARVA);
    }

    public void nakreslitObdelnik(int a, int b, Turtle neco, Color barva){
        neco.penDown();
        neco.setPenColor(barva);
        for (int i = 0; i < 2; i++){
            neco.move(a);
            neco.turnRight(90.0);
            neco.move(b);
            neco.turnRight(90.0);
        }
        neco.setPenColor(HLAVNI_BARVA);
        neco.penUp();
    }

    public void nakreslitTrojuhelnik(int stranaA, Turtle kreslic){
        if (stranaA < 30){
            System.out.println("Velikost trojuhelniku musi byt vetsi nez 10");
        } else {
            kreslic.penDown();
            for (int i = 0; i < 3; i++){
                kreslic.turnRight(120);
                kreslic.move(stranaA);
            }
            kreslic.penUp();
        }


    }
}
