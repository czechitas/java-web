package com.company;

public class Main {

    public static void main(String[] args) {

        StringBuilder honza = new StringBuilder("Honza");
        int cislo1 = 1;
        int cislo2 = 2;

        String honza2 = "Honza";
        String honza3 = "Mozny";
        String honza4 = "Ahoj";

        int vysledek = zmena(cislo1, cislo2);
        String nasString = zmena2(honza2);
        String dalsiNasString = zmena3(cislo1, honza2);

        char novaPromena = zmena4(honza2,honza3,honza4);

        System.out.println(vysledek);
        System.out.println(dalsiNasString);
        System.out.println(novaPromena);

    }

    public static int zmena(int jedna, int dva)  {
        int tri = jedna + dva;
        return tri;
    }

    public static String zmena2(String stringHonza) {
        return stringHonza;
    }

    public static String zmena3(int cisloJedna, String nasString) {
        String novyString = String.valueOf(cisloJedna);

        String vysledek = novyString + nasString;

        return vysledek;
    }

    public static char zmena4(String str1, String str2, String str3) {

        switch (str1) {
            case "Honza":
                System.out.println(str1);
                break;
            case "Mozny":
                System.out.println(str2);
                break;
            case "Ahoj":
                System.out.println(str3);
                break;
            default :
                System.out.println("Ahoj Honzo, nic jsem nenašel");
        };
        return 0;
    }
}
