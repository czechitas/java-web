package com.ryzizub;

public class Auto {

    private int rychlost;

    @Override
    public String toString() {
        return "Auto jede " + rychlost + " km/h ";
    }

    public void pridejRychlost(int pocet) {
        if (pocet < 0){
            System.out.println("pridavat muzes jen pocet >= 0");
        } else {
            rychlost = rychlost + pocet;
        }
    }

    public void odeberRychlost(int pocet) {
        if (pocet < 0){
            System.out.println("odebirat muzes jen pocet >= 0");
        } else {
            rychlost = rychlost - pocet;
        }
    }
}
