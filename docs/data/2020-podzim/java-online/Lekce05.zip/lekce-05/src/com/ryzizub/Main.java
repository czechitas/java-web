package com.ryzizub;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Mesto ostrava = new Mesto("Ostrava", 250000, 10 , 10);
//        Mesto newYork = new Mesto("New York", 1000000, 12 , 10);
//
//            try {
//                System.out.println(ostrava.jakDalekoOdMesta(null));
//
//            } catch (Exception err){
//                if (err instanceof NullPointerException){
//                    System.out.println("Nezadal mesto");
//                }
//            }

//        Auto rodinnyPeguet = new Auto();
//        Auto rodinnyBMW = new Auto();
//
//        ArrayList<Auto> seznamAut = new ArrayList<>();
//        seznamAut.add(rodinnyPeguet);
//        seznamAut.add(rodinnyBMW);
//
//        ostrava.pridejObyvatele(5, 2, seznamAut);
//        System.out.println(ostrava);
//        Auto mojeAuto = new Auto();
//        mojeAuto.pridejRychlost(50);
//        System.out.println(mojeAuto.toString());
//        mojeAuto.odeberRychlost(20);
//        System.out.println(mojeAuto.toString());





//        System.out.println(ostrava.toString());
//        ostrava.pridejObyvatele(1000);
//        System.out.println(ostrava.toString());
//
//
//
//        Mesto newyork = new Mesto("New York", 11000000);
//        System.out.println(newyork.toString() + ostrava.toString());
//        ostrava.pridejObyvatele(2000);
//        System.out.println(newyork.toString() + ostrava.toString());

//        int soucet = secti(10, 20);
//        System.out.println("Soucet je:" + soucet);


    }
//
//    public static int secti(int a, int b){
//        int soucet = a + b;
//        return soucet;
//    }

    // public - lze videt mimo tridu v jakemkoliv pripade
    // private  - nelze videt mimo tridu v jakemkoliv pripade
    // protected - nelze videt mimo tridu pokud neni rodicem

    // static - new nemusí být použito Math.round()
}
