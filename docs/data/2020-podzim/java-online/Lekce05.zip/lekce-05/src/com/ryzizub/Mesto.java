package com.ryzizub;

import java.util.ArrayList;

public class Mesto {

    private int pocetObyvatel;
    private String jmenoMesta;
    private int pocetAut;
    private ArrayList<Auto> seznamAut;
    public int x;
    public int y;

    Mesto(String predavaneJmeno, int predavanyPocet, int x, int y){
        jmenoMesta = predavaneJmeno;
        pocetObyvatel = predavanyPocet;
        pocetAut = 0;
        seznamAut = new ArrayList<Auto>();
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "Mesto " + jmenoMesta + " ma " + pocetObyvatel + " obyvatel a "+ pocetAut + " aut";
    }

    public void pridejObyvatele(int pocet) {
        if (pocet < 0){
            System.out.println("pridavat muzes jen pocet >= 0");
        } else {
            pocetObyvatel = pocetObyvatel + pocet;
        }
    }

    public void pridejObyvatele(int pocet, int pocetAut, ArrayList<Auto> seznamAut){
        this.pridejObyvatele(pocet);
        this.pridejAuta(pocetAut, seznamAut);

    }

    public void pridejAuta(int pocetAut, ArrayList<Auto> seznamAut){
        if (pocetAut < 0){
            System.out.println("pridavat muzes jen pocet >= 0");
        } else {
            this.pocetAut = this.pocetAut + pocetAut;
            this.seznamAut.addAll(seznamAut);
        }
    }

    public void odeberObyvatele(int pocet) {
        if (pocet < 0){
            System.out.println("odebirat muzes jen pocet >= 0");
        } else {
            pocetObyvatel = pocetObyvatel - pocet;
        }
    }

    public double jakDalekoOdMesta(Mesto druheMesto) {
        double vzdalenost = Math.floor((druheMesto.x - this.x)*(druheMesto.x - this.x) + (druheMesto.y - this.y)*(druheMesto.y - this.y)); //spatne
        return vzdalenost;
    }
}
