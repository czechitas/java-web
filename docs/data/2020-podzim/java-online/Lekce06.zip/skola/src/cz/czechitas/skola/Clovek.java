package cz.czechitas.skola;

public class Clovek {
    private String jmeno;
    private String prijmeni;
    private int vek;
    private int vyska;
    private int vaha;

    Clovek(String jmeno, String prijmeni, int vek, int vyska, int vaha){
        this.jmeno = jmeno;
        this.prijmeni = prijmeni;
        this.vek = vek;
        this.vyska = vyska;
        this.vaha = vaha;
    }

    public String vratJmenoPrijmeni(){
        return this.jmeno + " " + this.prijmeni;
    }

    @Override
    public String toString() {
        return "Clovek " +
                "jmeno='" + jmeno + '\'' +
                ", prijmeni='" + prijmeni + '\'' +
                ", vek=" + vek +
                ", vyska=" + vyska +
                ", vaha=" + vaha;
    }
}
