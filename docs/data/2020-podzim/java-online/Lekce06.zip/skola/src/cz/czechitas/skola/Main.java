package cz.czechitas.skola;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
//        Clovek neznamyClovek = new Clovek("Jan", "Mozny", 20, 185, 80);
//        System.out.println(neznamyClovek.vratJmenoPrijmeni());
//        System.out.println(neznamyClovek.toString());
//
        Zak mujZak = new Zak("Jan", "Mozny", 20, 185, 80);
        Zak mujZak2 = new Zak("Petra", "Mozny", 20, 185, 80);

//        Ucitel mujUcitelTelocviku = new Ucitel("Petr", "Novak", 45, 160, 120, "telocvik");

        UcitelMatematiky ucitelMatematiky = new UcitelMatematiky("Petr", "Fanas", 12, 160, 120);

        ArrayList<Zak> zaci = new ArrayList<>();
        zaci.add(mujZak);
        zaci.add(mujZak2);

        Trida mojePrvniTrida = new Trida(zaci, ucitelMatematiky);

        mojePrvniTrida.pridatZnamkuZMatematiky(0, 1);
        mojePrvniTrida.pridatZnamkuZMatematiky(0, 3);


        System.out.println(mojePrvniTrida.toString());

    }
}
