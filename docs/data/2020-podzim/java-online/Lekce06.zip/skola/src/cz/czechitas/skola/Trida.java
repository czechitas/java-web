package cz.czechitas.skola;

import java.util.ArrayList;

public class Trida {

    private ArrayList<Zak> seznamZaku;
    private Ucitel tridniUcitel;

    public Trida(ArrayList<Zak> seznamZaku, Ucitel tridniUcitel) {
        this.seznamZaku = seznamZaku;
        this.tridniUcitel = tridniUcitel;
    }

    public void pridatZnamkuZTelocviku(int index, int znamku){
        this.seznamZaku.get(index).pridejZnamkuTelocvik(znamku);
    }

    public void pridatZnamkuZMatematiky(int index, int znamku){
        this.seznamZaku.get(index).pridejZnamkuMatematika(znamku);
    }

    public int pocetZaku(){
        return seznamZaku.size();
    }

    @Override
    public String toString() {
        return "Trida{" +
                "pocetZaku=" + seznamZaku.size() +
                ", tridniUcitel=" + tridniUcitel.vratJmenoPrijmeni() +
                ", prumerZMatematiky=" + this.prumerZMatematiky() +
                '}';
    }

    public double prumerZMatematiky(){
        int soucet = 0;
        int pocet = 0;
        for (int i = 0; i< seznamZaku.size(); i++){
            for (int y = 0; y < seznamZaku.get(0).getZnamkyMatematika().size(); y++){
                soucet = soucet + seznamZaku.get(0).getZnamkyMatematika().get(y);
                pocet++;
            }
        }

        return soucet / pocet;
    }
}
