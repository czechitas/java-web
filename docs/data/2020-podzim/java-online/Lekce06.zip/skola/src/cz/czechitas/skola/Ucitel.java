package cz.czechitas.skola;

public class Ucitel extends Clovek {

    private String predmet;

    public Ucitel(String jmeno, String prijmeni, int vek, int vyska, int vaha, String predmet) {
        super(jmeno, prijmeni, vek, vyska, vaha);
        this.predmet = predmet;
    }

    @Override
    public String toString() {
        return "Ucitel{" +
                "predmet='" + predmet + '\'' +
                '}' + super.toString();
    }
}
