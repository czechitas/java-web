package cz.czechitas.skola;

public class UcitelMatematiky extends Ucitel {
    public UcitelMatematiky(String jmeno, String prijmeni, int vek, int vyska, int vaha) {
        super(jmeno, prijmeni, vek, vyska, vaha, "matematika");
    }
}
