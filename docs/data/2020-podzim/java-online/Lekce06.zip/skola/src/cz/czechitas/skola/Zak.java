package cz.czechitas.skola;

import java.util.ArrayList;

public class Zak extends Clovek{

    private ArrayList<Integer> znamkyMatematika;
    private ArrayList<Integer> znamkyTelocvik;

    public Zak(String jmeno, String prijmeni, int vek, int vyska, int vaha) {
        super(jmeno, prijmeni, vek, vyska, vaha);
        this.znamkyMatematika = new ArrayList<>();
        this.znamkyTelocvik = new ArrayList<>();
    }

    public ArrayList<Integer> getZnamkyTelocvik() {
        return znamkyTelocvik;
    }

    public ArrayList<Integer> getZnamkyMatematika() {
        return znamkyMatematika;
    }

    public void pridejZnamkuMatematika(int znamka){
        if (znamka > 5 || znamka <= 0){
            System.out.println("neplatna znamka");
        } else {
            znamkyMatematika.add(znamka);
        }
    }

    public void pridejZnamkuTelocvik(int znamka){
        if (znamka > 5 || znamka < 0){
            System.out.println("neplatna znamka");
        } else {
            znamkyTelocvik.add(znamka);
        }
    }



    // Ukol č.1 pole pro úkládání známek z matematiky a z telocviku a metody pro pridavani znamek do obou predmetu

}
