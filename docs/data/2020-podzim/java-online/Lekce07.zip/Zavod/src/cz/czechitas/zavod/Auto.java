package cz.czechitas.zavod;

public class Auto extends DopravniProstredek{

    private String znacka;

    public Auto(String jmeno, String znacka, int maximalnirychlost, int zrychleni) {
        super(jmeno, maximalnirychlost, zrychleni);
        this.znacka = znacka;
    }
}
