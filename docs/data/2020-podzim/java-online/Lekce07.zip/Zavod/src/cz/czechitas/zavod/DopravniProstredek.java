package cz.czechitas.zavod;

public class DopravniProstredek {

    private int rychlost;

    private int maximalniRychlost;

    private int zrychleni;

    private String jmeno;

    public DopravniProstredek(String jmeno, int maximalniRychlost, int zrychleni) {
        this.jmeno = jmeno;
        this.rychlost = 0;
        this.maximalniRychlost = maximalniRychlost;
        this.zrychleni = zrychleni;
    }

    public void pridej(){
        if (rychlost < maximalniRychlost){
            rychlost = rychlost + zrychleni;
        }
    }

    public void zpomal(){
        if (rychlost >= zrychleni){
            rychlost = rychlost - zrychleni;
        }
    }

    public boolean jedeMax(){
        if (rychlost == maximalniRychlost){
            return true;
        } else {
            return false;
        }
    }

    public boolean stoji(){
        if (rychlost == 0){
            return true;
        } else {
            return false;
        }
    }
}
