package cz.czechitas.zavod;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Auto zavodici1 = new Auto("moje porshe", "porshe", 240, 20);
        Auto zavodici2 = new Auto("moje skodovka", "skoda", 240, 5);
        Zavod zavod1 = new Zavod(20, "Velka cena Ostravy");
        zavod1.provestZavod(zavodici1, zavodici2);
        // Ukol c.1 Vytvorit tridu dopravni prostredek, ktera uklada rychlost a jmeno
        // Tridu auto ktera z ni dedi a ma ulozenou znacku auta
    }
}
