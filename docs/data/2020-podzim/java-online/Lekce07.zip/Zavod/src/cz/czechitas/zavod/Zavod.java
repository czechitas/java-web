package cz.czechitas.zavod;

public class Zavod {

    public int delka;

    public String jmeno;

    public Zavod(int delka, String jmeno) {
        this.delka = delka;
        this.jmeno = jmeno;
    }

    public void provestZavod(DopravniProstredek prvniZavodici, DopravniProstredek druhyZavodici){
        boolean probihaZavod = true;
        while (probihaZavod){
            if (prvniZavodici.jedeMax()){
                System.out.println("prvni vyhral");
                probihaZavod = false;
            }
            if (druhyZavodici.jedeMax()){
                System.out.println("druhy vyhral");
                probihaZavod = false;
            }
            prvniZavodici.pridej();
            druhyZavodici.pridej();
        }
    }
}
