package cz.czechitas.parkoviste;

public class Auto {

    private String znacka;

    private int sirka;

    public Auto(String znacka, int sirka) {
        this.znacka = znacka;
        this.sirka = sirka;
    }

    public String ziskatZnacku() {
        return znacka;
    }

    public int ziskatSirku() {
        return sirka;
    }
}
