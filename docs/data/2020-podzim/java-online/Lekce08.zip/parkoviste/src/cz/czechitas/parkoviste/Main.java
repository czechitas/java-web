package cz.czechitas.parkoviste;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here
        // Ukol c.1: vytvorit tridu Auto - znacka, int sirka - ziskatZnacku(), ziskatSirku()
        // vytvorit tridu Parkoviste - pole! mista a velke 10

        Auto auto = new Auto("porshe", 150);
        Parkoviste parkoviste = new Parkoviste();
        parkoviste.zaparkovatAuto(1, auto);
        parkoviste.jePlne(1);
        parkoviste.vyparkovatAuto(1);
    }
}
