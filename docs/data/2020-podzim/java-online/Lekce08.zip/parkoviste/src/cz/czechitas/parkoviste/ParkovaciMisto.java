package cz.czechitas.parkoviste;

public class ParkovaciMisto {

    private int sirka;
    public Auto zaparkovanoAuto;

    public ParkovaciMisto(int sirka) {
        this.sirka = sirka;
    }

    public int ziskatSirku(){
        return this.sirka;
    }

    public void zaparkovatAuto(Auto prijizdejiciAuto){
        if (prijizdejiciAuto.ziskatSirku() <= this.ziskatSirku()){
            this.zaparkovanoAuto = prijizdejiciAuto;
        }
    }

    public void vyparkovatAuto(){
        this.zaparkovanoAuto = null;
    }
}
