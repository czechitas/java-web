package cz.czechitas.parkoviste;

import java.util.ArrayList;

public class Parkoviste {

    private ArrayList<ParkovaciMisto> mista;

    Parkoviste(){
        mista = new ArrayList<>(5);
        ParkovaciMisto misto1 = new ParkovaciMisto(200);
        ParkovaciMisto misto2 = new ParkovaciMisto(200);
        ParkovaciMisto misto3 = new ParkovaciMisto(200);
        ParkovaciMisto misto4 = new ParkovaciMisto(200);
        ParkovaciMisto misto5 = new ParkovaciMisto(200);
        mista.add(misto1);
        mista.add(misto2);
        mista.add(misto3);
        mista.add(misto4);
        mista.add(misto5);
    }

    public void zaparkovatAuto(int index, Auto auto){
        if (mista.get(index).zaparkovanoAuto == null){
            mista.get(index).zaparkovatAuto(auto);
        }
        System.out.println("zaparkoval jste vase " + auto.ziskatZnacku());
    }

    public boolean jePlne(int index){
        if (mista.get(index).zaparkovanoAuto != null){
            return true;
        } else {
            return false;
        }
    }

    public void vyparkovatAuto(int index){
        mista.get(index).vyparkovatAuto();
    }
}
