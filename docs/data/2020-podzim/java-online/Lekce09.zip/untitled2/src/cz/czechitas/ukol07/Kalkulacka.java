package cz.czechitas.ukol07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kalkulacka {

    int vysledek = 0;

    Kalkulacka() {
        JFrame frame = new JFrame("Moje okno");
        frame.setSize(300,300);

        JTextField textField = new JTextField();
        frame.add(textField);
        JButton button2 = new JButton("2");
        JButton button3 = new JButton("3");
        JButton button4 = new JButton("4");
        JButton button5 = new JButton("5");
        JButton button6 = new JButton("6");
        JButton button7 = new JButton("7");
        JButton button8 = new JButton("8");
        JButton button9 = new JButton("9");
        JButton buttonMinus = new JButton("-");
        JButton buttonEnd = new JButton("=");
        vytvorJednicku(frame);

        frame.add(button2);
        frame.add(button3);
        frame.add(button4);
        frame.add(button5);
        frame.add(button6);
        frame.add(button7);
        frame.add(button8);
        frame.add(button9);
        vytvorPlus(frame);
        frame.add(buttonMinus);
        frame.add(buttonEnd);
        frame.setLayout(new GridLayout(4, 3));
        frame.setVisible(true);

    }

    private void vytvorJednicku(JFrame okno){
        JButton button = new JButton("1");
        okno.add(button);
        ActionListener actionJedna = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("1");
            }
        };
        button.addActionListener(actionJedna);
    }

    private void vytvorPlus(JFrame okno){
        JButton button = new JButton("+");
        okno.add(button);
        ActionListener actionJedna = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                vysledek = vysledek + 1;
                System.out.println(vysledek);
            }
        };
        button.addActionListener(actionJedna);
    }
}
