package cz.czechitas.ukol07;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Kalkulacka kalkulacka = new Kalkulacka();
        // Ukol 1. 9 - 1-9
        // + - =
    }
}
