package cz.czechitas.prevod;

public class Main {

    public static void main(String[] args) {
        new Prevodnik().vykreslit();
    }
}
