package cz.czechitas.prevod;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Prevodnik {

    final String[] meny = { "CZK", "EUR", "USD" };

    String vybranaMenaPrvni = "CZK";
    String vybranaMenaDruha = "EUR";

    double czkEur = 0.038;
    double czkUsd = 0.046;
    double usdCzk = 21.84;
    double eurCzk = 26.48;

    void vykreslit(){
        JFrame okno = new JFrame();
        okno.setSize(500, 300);

        JLabel label = new JLabel();
        label.setText("Zadej prevadenou hodnotu");
        okno.add(label);

        JTextField mujVstup = new JTextField(10);
        okno.add(mujVstup);

        JComboBox listMen = new JComboBox(meny);
        listMen.setSelectedItem(vybranaMenaPrvni);
        listMen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JComboBox cb = (JComboBox) actionEvent.getSource();
                vybranaMenaPrvni = cb.getSelectedItem().toString();
                System.out.println(vybranaMenaPrvni);
            }
        });
        okno.add(listMen);

        JComboBox druhyListMen = new JComboBox(meny);
        druhyListMen.setSelectedItem(vybranaMenaDruha);
        druhyListMen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JComboBox cb = (JComboBox) actionEvent.getSource();
                vybranaMenaDruha = cb.getSelectedItem().toString();
            }
        });
        okno.add(druhyListMen);

        JButton buttonVypocteni = new JButton("Vypocitat");
        JLabel vysledek = new JLabel(" ");

        buttonVypocteni.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String vstup = mujVstup.getText();
                try {
                    double cislo = Double.parseDouble(vstup);
                    Double vy = preved(cislo, vybranaMenaPrvni, vybranaMenaDruha);
                    vysledek.setText(vy.toString());
                    System.out.println(cislo);
                } catch (Exception exception){
                    System.out.println(exception.toString());
                }

            }
        });
        okno.add(buttonVypocteni);

        JLabel jLabel = new JLabel("Vysledek: ");
        okno.add(jLabel);

        okno.add(vysledek);

        okno.setLayout(new FlowLayout());

        okno.setVisible(true);

    }

    Double preved(double vstup, String vstupniMena, String vystupniMena){
        switch (vstupniMena){
            case "CZK": {//CZK
                switch (vystupniMena){
                    case "CZK": //CZK - CZK
                        return vstup;
                    case "EUR": //CZK - EUR
                        return vstup * czkEur;
                    case "USD": //CZK - USD
                        return vstup * czkUsd;
                }
            }
            case "EUR": //EUR
                switch (vystupniMena){
                    case "CZK": //CZK - CZK
                        return vstup * eurCzk;
                    case "EUR":
                        return vstup;//CZK - EUR
                    case "USD": //CZK - USD
                        return vstup * czkUsd;// TODO spatny kurz
                }
            case "USD": //USD
                switch (vystupniMena){
                    case "CZK": //CZK - CZK
                        return vstup * usdCzk;
                    case "EUR": //CZK - EUR
                        return vstup * czkUsd;// spatny kurz
                    case "USD": //CZK - USD
                        return vstup ;
                }
            default:
                return 0.0;
        }
    }
}
