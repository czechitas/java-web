package cz.czechitas.kalkulacka;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Formular extends JFrame implements ActionListener {

    JTextField vstupJmeno;
    JTextField vstupHeslo;
    JTextField vstupEmail;

    Formular(){
        super("JFrame Registration Demo");
        setLayout(new BorderLayout());

        JPanel panelFormular = new JPanel();
        panelFormular.setLayout(new GridLayout(3,2));

        panelFormular.add(new JLabel("Enter your name: "));

        vstupJmeno = new JTextField();
        panelFormular.add(vstupJmeno);

        panelFormular.add(new JLabel("Enter your password: "));

        vstupHeslo = new JTextField();
        panelFormular.add(vstupHeslo);
         panelFormular.add(new JLabel("Enter email: "));

        vstupEmail = new JTextField();
        panelFormular.add(vstupEmail);

        JLabel nadpis = new JLabel("This is the heading panel for our demo course");
        JPanel panelNadpisu = new JPanel();
        panelNadpisu.setLayout(new BorderLayout());
        panelNadpisu.add(nadpis, BorderLayout.CENTER);

        JButton jButton = new JButton("Register");
        jButton.addActionListener(this);

        add(panelNadpisu, BorderLayout.NORTH);
        add(panelFormular, BorderLayout.CENTER);
        add(jButton, BorderLayout.SOUTH);

        setVisible(true);
        setSize(300,300);
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        System.out.println(vstupJmeno.getText());
        System.out.println(vstupEmail.getText());
        System.out.println(vstupHeslo.getText());

        vstupJmeno.setText(" ");
        vstupEmail.setText(" ");
        vstupHeslo.setText(" ");
    }
}
