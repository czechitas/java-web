package cz.czechitas.kalkulacka;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kalkulacka extends JFrame implements ActionListener {

    JButton b[] = new JButton[17];

    String hodnoty[] = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "=", "+", "C"};

    Kalkulacka(){
        super("Kalkulacka");
        setSize(300,300);
        setVisible(true);
        setLayout(new BorderLayout());

        JPanel panelTlacitek = new JPanel();

        panelTlacitek.setLayout(new GridLayout(5, 4));
        for (Integer i = 0; i<hodnoty.length;i++){
            JButton button = new JButton(hodnoty[i]);
            button.addActionListener(this);
            b[i] = button;
            panelTlacitek.add(b[i]);
        }

        JTextField info = new JTextField(10);

        add(panelTlacitek, BorderLayout.CENTER);
        add(info, BorderLayout.NORTH);
        setVisible(true);
        setSize(300,300);
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        JButton kliknuteTlacitko = (JButton) actionEvent.getSource();
        String kliknutytext = kliknuteTlacitko.getText();
        switch (kliknutytext) {
            case "+":
                break;
            case "-":
                break;
            case "/":
                break;
            case "*":
                break;
            case ".":
                break;
            case "=":
                break;
            case "C":
                break;
            default:
                System.out.println("zavolalo se cislo");
                break;
        }
    }

//    void vykreslit(){
//        JFrame jFrame = new JFrame();
//        jFrame.setSize(300, 300);
//        jFrame.setVisible(true);
//    }
}
