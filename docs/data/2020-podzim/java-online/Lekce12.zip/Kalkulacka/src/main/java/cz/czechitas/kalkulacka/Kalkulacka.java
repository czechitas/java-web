package cz.czechitas.kalkulacka;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Kalkulacka extends JFrame implements ActionListener {

    JButton b[] = new JButton[17];

    String hodnoty[] = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "=", "+", "C"};

    JTextField info;

    String matematickaOperace = "";

    Double prvniCislo = 0.0;

    Kalkulacka(){
        super("Kalkulacka");
        setSize(300,300);
        setVisible(true);
        setLayout(new BorderLayout());

        JPanel panelTlacitek = new JPanel();

        panelTlacitek.setLayout(new GridLayout(5, 4));
        for (Integer i = 0; i<hodnoty.length;i++){
            JButton button = new JButton(hodnoty[i]);
            button.addActionListener(this);
            b[i] = button;
            panelTlacitek.add(b[i]);
        }

        info = new JTextField(10);
        info.setEditable(false);

        add(panelTlacitek, BorderLayout.CENTER);
        add(info, BorderLayout.NORTH);
        setVisible(true);
        setSize(300,300);
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        JButton kliknuteTlacitko = (JButton) actionEvent.getSource();
        String kliknutytext = kliknuteTlacitko.getText();
        String vstup = info.getText();
        switch (kliknutytext) {
            case "+":
            case "-":
            case "/":
            case "*":
                matematickaOperace = kliknutytext;
                if (vstup.length() == 0){
                    info.setText("Nezadal zadne cislo klikni C a zacni znovu");
                } else {
                    prvniCislo = Double.parseDouble(vstup);
                    vstup = vstup + kliknutytext;
                    info.setText(vstup);
                }
                break;
            case "=":
                if (vstup.length() == 0){
                    info.setText("Nezadal zadne cislo klikni C a zacni znovu");
                } else {
                    //12*12
                    double druheCislo = Double.parseDouble(vstup.substring(prvniCislo.toString().length() - 1 ));
                    Double vysledek = 0.0;
                    switch (matematickaOperace){
                        case "/":
                            vysledek = prvniCislo / druheCislo;
                            break;
                        case "+":
                            vysledek = prvniCislo + druheCislo;
                            break;
                        case "-":
                            vysledek = prvniCislo - druheCislo;
                            break;
                        case "*":
                            vysledek = prvniCislo * druheCislo;
                            break;
                    }
                    info.setText(vstup + "=" + vysledek.toString());
                }
                break;
            case "C":
                info.setText("");
                prvniCislo = 0.0;
                matematickaOperace = "";
                break;
            default:
                vstup = vstup + kliknutytext;
                info.setText(vstup);
                break;
        }

    }

//    void vykreslit(){
//        JFrame jFrame = new JFrame();
//        jFrame.setSize(300, 300);
//        jFrame.setVisible(true);
//    }
}
