package cz.czechitas.kalkulacka;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
//        JFrame jFrame = new JFrame();
//        jFrame.setSize(300,300);
//        new Kalkulacka().vykreslit(jFrame);

//        jFrame.setVisible(true);
//        new Kalkulacka().vykreslit();





        new Kalkulacka();
    }
}
