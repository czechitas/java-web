package cz.czechitas.intro;

import cz.czechitas.intro.api.*;
import net.sevecek.util.*;

public class HlavniProgram {

    public void main(String[] args) {

//        AngryRed mujRed = new AngryRed(400, 200);
//
//        AngryMatilda mojeMatydla = new AngryMatilda(100, 100);
//
//        for (int i = 0; i < 4; i++) {
//            mujRed.moveForward(100);
//            mujRed.turnRight();
//        }


        // TODO: Sem vepiste svuj program


    }

}
