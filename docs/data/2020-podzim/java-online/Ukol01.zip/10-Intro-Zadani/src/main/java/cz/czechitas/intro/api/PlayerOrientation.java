package cz.czechitas.intro.api;

public enum PlayerOrientation {

    UP,
    RIGHT,
    DOWN,
    LEFT

}
