package cz.czechitas.ukol07;

public class Cestujici extends Clovek {
    private Jizdenka jizdenka;

    Cestujici(String jmeno, String prijmeni, Jizdenka jizdenka) {
        super(jmeno, prijmeni);
        this.jizdenka = jizdenka;
    }

    @Override
    public String toString() {
        return "Cestujici{" +
                "clovek=" + super.ziskatJmenoPrijmeni() + "," +
                "jizdenka=" + jizdenka +
                '}';
    }

    public Jizdenka ziskatJizdenku() {
        return this.jizdenka;
    }
}
