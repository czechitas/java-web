package cz.czechitas.ukol07;

public class Clovek {

    private String jmeno;

    private String prijmeni;

    Clovek(String jmeno, String prijmeni){
        this.jmeno = jmeno;
        this.prijmeni = prijmeni;
    }

    @Override
    public String toString() {
        return "Clovek{" +
                "jmeno='" + jmeno + '\'' +
                ", prijmeni='" + prijmeni + '\'' +
                '}';
    }

    public String ziskatJmenoPrijmeni() {
        return this.jmeno + " " + this.prijmeni;
    }
}
