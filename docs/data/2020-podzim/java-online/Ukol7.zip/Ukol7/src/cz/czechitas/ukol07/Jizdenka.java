package cz.czechitas.ukol07;

public class Jizdenka {

    private String kodVagonu;

    private Boolean platna;

    private Boolean zkontrolovana;

    Jizdenka(String kodVagonu, Boolean platna) {
        this.kodVagonu = kodVagonu;
        this.platna = platna;
        this.zkontrolovana = false;
    }

    @Override
    public String toString() {
        return "Jizdenka{" +
                "kodVagonu='" + kodVagonu + '\'' +
                ", platna=" + platna +
                ", zkontrolovana=" + zkontrolovana +
                '}';
    }

    public boolean jePlatna() {
        return this.platna;
    }

    public String ziskatKodVagonu() {
        return this.kodVagonu;
    }

    public boolean jeZkontrolovana() {
        return this.zkontrolovana;
    }

    public void zkontrolovat() {
        this.zkontrolovana = true;
    }
}
