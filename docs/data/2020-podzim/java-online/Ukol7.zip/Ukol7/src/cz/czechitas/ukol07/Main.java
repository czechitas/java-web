package cz.czechitas.ukol07;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Jizdenka jizdenka = new Jizdenka("K048", true);
        Cestujici cestujici = new Cestujici("Petra", "Zavata", jizdenka);

        Jizdenka jizdenka2 = new Jizdenka("K049", false);
        Cestujici cestujici2 = new Cestujici("Tomas", "Hlavina", jizdenka2);

        Vagon vagon1 = new Vagon("K048");
        Vagon vagon2 = new Vagon("K049");
        ArrayList<Vagon> vagony = new ArrayList<>();
        vagon1.pridatCestujiciho(cestujici);
        vagon2.pridatCestujiciho(cestujici2);

        Vlak pendolino = new Vlak(vagony, true);
    }
}
