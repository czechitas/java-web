package cz.czechitas.ukol07;

import java.util.ArrayList;

public class Vagon {

    private ArrayList<Cestujici> cestujici;

    private String kodVagonu;

    Vagon(String kodVagonu){
        this.kodVagonu = kodVagonu;
        this.cestujici = new ArrayList<>();
    }

    @Override
    public String toString() {
        return "Vagon{" +
                "pocetCestujicich=" + cestujici.size() +
                ", kodVagonu='" + kodVagonu + '\'' +
                '}';
    }

    public void pridatCestujiciho(Cestujici cestujici){
        if (cestujici.ziskatJizdenku().jePlatna()){
            if (cestujici.ziskatJizdenku().ziskatKodVagonu() == kodVagonu){
                cestujici.ziskatJizdenku().zkontrolovat();
                this.cestujici.add(cestujici);
            } else {
                System.out.println("Cestujici chce nastoupit na spatny vagon");
            }
        } else {
            System.out.println("Cestujici nema platnou jizdenku");
        }
    }

    public Cestujici ziskatCestujiciho(int index){
        if (index <= this.cestujici.size() -1 ){
            return cestujici.get(index);
        } else {
            return null;
        }
    }
}
