package cz.czechitas.ukol07;

import java.util.ArrayList;

public class Vlak {

    private ArrayList<Vagon> vagony;

    private boolean jede;

    Vlak(ArrayList<Vagon> vagony, boolean jede){
        this.jede = jede;
    }

    @Override
    public String toString() {
        return "Vlak{" +
                "pocetVagonu=" + vagony.size() +
                ", jede=" + jede +
                '}';
    }

    public boolean ziskatStav(){
        return jede;
    }
}
