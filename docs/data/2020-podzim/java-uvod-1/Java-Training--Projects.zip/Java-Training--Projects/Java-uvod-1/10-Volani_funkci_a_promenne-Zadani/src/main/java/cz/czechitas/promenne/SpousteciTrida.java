package cz.czechitas.promenne;

public class SpousteciTrida {

    public static void main(String[] args) {
        System.out.println("Ahoj pozemstani, zavedte me ke svemu veliteli");
    }

}
