package cz.czechitas.angrybirds.api;

public enum Cell {

    EMPTY,
    WOODEN_BOX,
    WOODEN_TRIANGLE, STONE_TRIANGLE, GLASS_TRIANGLE, TNT, STONE_BOX

}
