package cz.czechitas.promenne;

import java.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        /*
        String jmeno;
        String mesto;
        System.out.print("Zadejte svoje jmeno: ");
        jmeno = console.nextLine();
        System.out.print("Zadejte svoje mesto: ");
        mesto = console.nextLine();
        System.out.println("Ahoj, " + jmeno + " zdravi " + mesto + ".");
        */

        /*
        int pocetHus;
        int pocetKraliku;
        System.out.print("Zadejte pocet hus na farme: ");
        pocetHus = console.nextInt();
        System.out.print("Zadejte pocet kraliku na farme: ");
        pocetKraliku = console.nextInt();
        int pocetZvirat;
        int pocetNohou;
        pocetZvirat = pocetHus + pocetKraliku;
        pocetNohou = pocetHus * 2 + pocetKraliku * 4;
        System.out.println("Na frame je " + pocetZvirat + " zvirat a maji " + pocetNohou + " nohou.");
        */

        /*
        double celkovaCena;
        double castkaKZaplaceni;
        System.out.print("Zadejte celkovou cenu nakupu: ");
        celkovaCena = console.nextDouble();
        castkaKZaplaceni = Math.round(celkovaCena);
        System.out.println("Celkova cena: " + celkovaCena);
        System.out.println("Castka k zaplaceni: " + castkaKZaplaceni);
        */

        /*
        int rokNarozeni;
        int stari;
        System.out.print("Zadejte rok sveho narozeni: ");
        rokNarozeni = console.nextInt();
        stari = 2020 - rokNarozeni;
        System.out.println("Tento rok budete mit " + stari + " let.");
        */

        /*
        int nahodnaPravdepodobnost;
        nahodnaPravdepodobnost = (int) (Math.random() * 100.0);
        System.out.println("Pravdepodobnost uspechu je " + nahodnaPravdepodobnost + " %.");
        */

        /*
        int delka;
        int sirka;
        System.out.print("Zadejte delku obdelniku: ");
        delka = console.nextInt();
        System.out.print("Zadejte sirku obdelniku: ");
        sirka = console.nextInt();
        int obvod = 2 * delka + 2 * sirka;
        int obsah = delka * sirka;
        System.out.println("Obdelnik: obvod = " + obvod + ", obsah = " + obsah);
        */
    }

}
