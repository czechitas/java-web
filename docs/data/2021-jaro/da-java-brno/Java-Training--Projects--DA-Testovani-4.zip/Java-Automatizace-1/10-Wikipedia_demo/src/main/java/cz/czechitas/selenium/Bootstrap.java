package cz.czechitas.selenium;

public class Bootstrap {

    public static void main(String[] args) throws Exception {
        var program = new HlavniProgram();
        program.run();
    }
}
