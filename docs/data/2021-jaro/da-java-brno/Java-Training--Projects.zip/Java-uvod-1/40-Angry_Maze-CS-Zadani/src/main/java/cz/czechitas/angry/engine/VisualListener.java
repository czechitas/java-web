package cz.czechitas.angry.engine;

public interface VisualListener {

    void levelChanged();

    void startExecuted();

    void pauseExecuted();

    void resetExecuted();

    void nullEndExecuted();

    void negativeEndExecuted();

    void positiveEndExecuted();

}
