package cz.czechitas.intro.api;

import javax.swing.*;

public interface Stackable {

    Icon getStackableIcon();

}
