package cz.czechitas.intro.api;

public interface Brain {

    void controlPlayer(Player p);

}
