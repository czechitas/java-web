package cz.czechitas.intro.api;

public enum CollisionType {
    NO_COLLISION,
    COLLISION,
    STACKABLE_COLLISION
}
