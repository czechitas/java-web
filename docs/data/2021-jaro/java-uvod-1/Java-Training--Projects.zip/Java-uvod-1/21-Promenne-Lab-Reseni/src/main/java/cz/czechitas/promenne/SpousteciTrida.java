package cz.czechitas.promenne;

import java.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        var console = new Scanner(System.in);

        System.out.print("Zadejte svoje jmeno: ");
        var jmeno = console.nextLine();
        System.out.print("Zadejte svoje mesto: ");
        var mesto = console.nextLine();
        System.out.println("Ahoj, " + jmeno + " zdravi " + mesto + ".");

        System.out.print("Zadejte pocet hus na farme: ");
        var pocetHus = console.nextInt();
        System.out.print("Zadejte pocet kraliku na farme: ");
        var pocetKraliku = console.nextInt();
        var pocetZvirat = pocetHus + pocetKraliku;
        var pocetNohou = pocetHus * 2 + pocetKraliku * 4;
        System.out.println("Na frame je " + pocetZvirat + " zvirat a maji " + pocetNohou + " nohou.");

        System.out.print("Zadejte celkovou cenu nakupu: ");
        var celkovaCena = console.nextDouble();
        var castkaKZaplaceni = Math.round(celkovaCena);
        System.out.println("Celkova cena: " + celkovaCena);
        System.out.println("Castka k zaplaceni: " + castkaKZaplaceni);

        System.out.print("Zadejte rok sveho narozeni: ");
        var rokNarozeni = console.nextInt();
        var stari = 2020 - rokNarozeni;
        System.out.println("Tento rok budete mit " + stari + " let.");

        var nahodnaPravdepodobnost = (int) (Math.random() * 100.0);
        System.out.println("Pravdepodobnost uspechu je " + nahodnaPravdepodobnost + " %.");

        System.out.print("Zadejte delku obdelniku: ");
        var delka = console.nextInt();
        System.out.print("Zadejte sirku obdelniku: ");
        var sirka = console.nextInt();
        var obvod = 2 * delka + 2 * sirka;
        var obsah = delka * sirka;
        System.out.println("Obdelnik: obvod = " + obvod + ", obsah = " + obsah);

        System.out.print("Zadejte prvni cislo: ");
        var cislo1 = console.nextDouble();
        System.out.print("Zadejte druhe cislo: ");
        var cislo2 = console.nextDouble();
        var soucet = cislo1 + cislo2;
        var rozdil = cislo1 - cislo2;
        var soucin = cislo1 * cislo2;
        var podil = cislo1 / cislo2;
        System.out.println("Pocitam: " + cislo1 + " + " + cislo2 + " = " + soucet);
        System.out.println("Pocitam: " + cislo1 + " - " + cislo2 + " = " + rozdil);
        System.out.println("Pocitam: " + cislo1 + " * " + cislo2 + " = " + soucin);
        System.out.println("Pocitam: " + cislo1 + " / " + cislo2 + " = " + podil);

        System.out.print("Zadejte vzdálenost v metrech: ");
        var delkaVMetrech = console.nextDouble();
        var delkaVCm = delkaVMetrech * 100.0;
        var delkaVKm = delkaVMetrech / 1000.0;
        var delkaVMilich = delkaVMetrech * 0.000621371192;
        var delkaVYard = delkaVMetrech * 1.0936133;
        var delkaVInch = delkaVMetrech * 39.3700787;
        System.out.println(delkaVCm + " cm");
        System.out.println(delkaVKm + " km");
        System.out.println(delkaVMilich + " mi");
        System.out.println(delkaVYard + " yard");
        System.out.println(delkaVInch + " inch");
    }

}
