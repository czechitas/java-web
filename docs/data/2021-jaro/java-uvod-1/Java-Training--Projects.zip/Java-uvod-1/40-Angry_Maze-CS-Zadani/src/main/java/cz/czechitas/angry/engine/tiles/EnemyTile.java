package cz.czechitas.angry.engine.tiles;

public class EnemyTile extends GenericTile {

    public EnemyTile() {
        super("enemy.png");
    }

}
