package cz.czechitas.angry.engine.tiles;

public class ExplosionTile extends GenericTile {

    public ExplosionTile() {
        super("explosion.png");
    }
}
