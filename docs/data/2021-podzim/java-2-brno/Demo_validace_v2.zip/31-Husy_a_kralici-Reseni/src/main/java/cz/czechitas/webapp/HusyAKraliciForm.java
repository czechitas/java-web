package cz.czechitas.webapp;

public class HusyAKraliciForm {

    private int pocetHus;
    private int pocetKraliku;

    public int getPocetHus() {
        return pocetHus;
    }

    public void setPocetHus(int newValue) {
        pocetHus = newValue;
    }

    public int getPocetKraliku() {
        return pocetKraliku;
    }

    public void setPocetKraliku(int newValue) {
        pocetKraliku = newValue;
    }
}
