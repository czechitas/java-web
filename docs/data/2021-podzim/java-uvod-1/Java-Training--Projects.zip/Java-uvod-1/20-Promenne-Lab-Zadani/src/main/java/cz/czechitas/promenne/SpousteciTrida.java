package cz.czechitas.promenne;

import java.util.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        var console = new Scanner(System.in);

        System.out.println("Ahoj pozemstani, zavedte me ke svemu veliteli");
    }

}
