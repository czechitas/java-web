package cz.czechitas.angry.api;

public enum PlayerOrientation {

    WEST,
    EAST,
    NORTH,
    SOUTH

}
