package cz.czechitas.kockamyssyr.api;

public enum CollisionType {
    NO_COLLISION,
    COLLISION,
    STACKABLE_COLLISION
}
